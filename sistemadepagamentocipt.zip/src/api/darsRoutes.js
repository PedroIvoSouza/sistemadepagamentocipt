const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const authMiddleware = require('../middleware/authMiddleware'); // Nosso "segurança"
const { calcularEncargosAtraso } = require('../services/cobrancaService');

const router = express.Router();
const db = new sqlite3.Database('./sistemacipt.db');

// ROTA ATUALIZADA: GET /api/dars (Agora com filtros)
router.get('/', authMiddleware, (req, res) => {
    const userId = req.user.id;
    const { ano, status } = req.query; // Pega os filtros da URL, ex: /api/dars?ano=2025&status=Pendente

    let sql = `SELECT * FROM dars WHERE permissionario_id = ?`;
    const params = [userId];

    if (ano && ano !== 'todos') {
        sql += ` AND ano_referencia = ?`;
        params.push(ano);
    }

    if (status && status !== 'todos') {
        sql += ` AND status = ?`;
        params.push(status);
    }

    sql += ` ORDER BY ano_referencia DESC, mes_referencia DESC`;
    
    db.all(sql, params, (err, rows) => {
        if (err) {
            return res.status(500).json({ error: 'Erro de banco de dados.' });
        }
        res.status(200).json(rows);
    });
});


// --- 2. NOVA ROTA ADICIONADA AQUI ---
// ROTA PROTEGIDA: GET /api/dars/:id/recalcular
// Pega um DAR específico e, se estiver vencido, calcula os encargos.
router.get('/:id/recalcular', authMiddleware, (req, res) => {
    const userId = req.user.id;
    const darId = req.params.id;

    // Busca o DAR específico no banco, garantindo que ele pertence ao usuário logado
    const sql = `SELECT * FROM dars WHERE id = ? AND permissionario_id = ?`;
    
    db.get(sql, [darId, userId], async (err, dar) => {
        if (err) {
            return res.status(500).json({ error: 'Erro de banco de dados.' });
        }
        if (!dar) {
            return res.status(404).json({ error: 'DAR não encontrado ou não pertence a este usuário.' });
        }

        try {
            // Usa a nossa calculadora para obter os valores atualizados
            const calculo = await calcularEncargosAtraso(dar);
            res.status(200).json(calculo); // Retorna o objeto com os detalhes do cálculo
        } catch (error) {
            res.status(500).json({ error: 'Erro ao calcular encargos.' });
        }
    });
});


module.exports = router;