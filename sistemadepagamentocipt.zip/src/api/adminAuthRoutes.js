const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const router = express.Router();
const db = new sqlite3.Database('./sistemacipt.db');

// ROTA: POST /api/admin/auth/login
router.post('/login', (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ error: 'E-mail e senha são obrigatórios.' });
    }

    const sql = `SELECT * FROM administradores WHERE email = ?`;
    db.get(sql, [email], async (err, admin) => {
        if (err) { return res.status(500).json({ error: 'Erro de banco de dados.' }); }
        if (!admin) { return res.status(401).json({ error: 'Credenciais inválidas.' }); }

        const passwordMatch = await bcrypt.compare(password, admin.senha);
        if (!passwordMatch) { return res.status(401).json({ error: 'Credenciais inválidas.' }); }

        // Gera um token JWT para o admin
        const payload = { id: admin.id, nome: admin.nome, isAdmin: true }; // Adicionamos isAdmin para diferenciar
        const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '8h' });

        res.status(200).json({ 
            message: 'Login de administrador bem-sucedido!',
            token: token 
        });
    });
});

module.exports = router;